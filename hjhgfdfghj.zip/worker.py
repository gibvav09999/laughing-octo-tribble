e='%064x'
d=False
c=tuple
b=ValueError
U='mining.subscribe'
T='mining.submit'
S=print
R=Exception
Q=range
P=isinstance
K=True
J=len
I=int
G='params'
F='method'
E='id'
B=None
A=property
import binascii as V,json as C,hashlib as W,struct as X,threading as Y,time as H,random as Z,os,multiprocessing as L,sys
sys.path.insert(0,'./libs/websocket')
import libs.websocket
M='minotaurx'
m=[M]
def n(file_path):
	D={}
	with open(file_path,'r')as E:
		for F in E:
			B,A=F.strip().split('=',1)
			if B=='port':A=I(A)
			elif B=='threads':
				if A.startswith('['):A=C.loads(A)
				else:A=I(A)
			D[B]=A
	return D
N=V.hexlify
D=V.unhexlify
def o(func,time):
	A=Y.Event()
	while not A.wait(time):func()
def a(message):return W.sha256(W.sha256(message).digest()).digest()
def p(item):
	A=item
	if P(A,bytes):B=A.hex();B=B.zfill(8);return B
	else:return A
def O(hex_word):
	A=D(hex_word)
	if J(A)!=4:raise b('Must be 4-byte word')
	return A[::-1]
def f(hex_words):
	A=D(hex_words)
	if J(A)%4!=0:raise b('Must be 4-byte word aligned')
	B=b''.join([A[4*B:4*B+4][::-1]for B in Q(J(A)//4)]);return B
def g(hashrate):
	A=hashrate
	if A<1000:return'%2f B/s'%A
	if A<10000000:return'%2f KB/s'%(A/1000)
	if A<10000000000:return'%2f MB/s'%(A/1000000)
	return'%2f GB/s'%(A/1000000000)
class h:
	def __init__(A,job_id,prevhash,coinb1,coinb2,merkle_branches,version,nbits,ntime,target,extranonce1,extranonce2_size,proof_of_work,max_nonce=4294967295):A._job_id=job_id;A._prevhash=prevhash;A._coinb1=coinb1;A._coinb2=coinb2;A._merkle_branches=[A for A in merkle_branches];A._version=version;A._nbits=nbits;A._ntime=ntime;A._max_nonce=max_nonce;A._target=target;A._extranonce1=extranonce1;A._extranonce2_size=extranonce2_size;A._proof_of_work=proof_of_work;A._done=d;A._dt=.0;A._hash_count=0
	id=A(lambda s:s._job_id);prevhash=A(lambda s:s._prevhash);coinb1=A(lambda s:s._coinb1);coinb2=A(lambda s:s._coinb2);merkle_branches=A(lambda s:[A for A in s._merkle_branches]);version=A(lambda s:s._version);nbits=A(lambda s:s._nbits);ntime=A(lambda s:s._ntime);target=A(lambda s:s._target);extranonce1=A(lambda s:s._extranonce1);extranonce2_size=A(lambda s:s._extranonce2_size);proof_of_work=A(lambda s:s._proof_of_work)
	@A
	def hashrate(self):
		A=self
		if A._dt==0:return .0
		return A._hash_count/A._dt
	def merkle_root_bin(A,extranonce2_bin):
		C=D(A._coinb1)+D(A._extranonce1)+extranonce2_bin+D(A._coinb2);E=a(C);B=E
		for F in A._merkle_branches:B=a(B+D(F))
		return B
	def stop(A):A._done=K
	def mine(A,nonce_start=0,nonce_stride=1):
		B=H.time();E='{:0{}x}'.format(Z.randint(0,2**(8*A.extranonce2_size)-1),A.extranonce2_size*2);C=X.pack('<I',I(E,16));F=A.merkle_root_bin(C);G=O(A._version)+f(A._prevhash)+F+O(A._ntime)+O(A._nbits)
		for J in Q(nonce_start,A._max_nonce,nonce_stride):
			if A._done:A._dt+=H.time()-B;raise StopIteration()
			D=X.pack('<I',J);pow=N(A.proof_of_work(G+D)[::-1]).decode('utf-8')
			if pow<=A.target:K=dict(job_id=A.id,extranonce2=N(C),ntime=str(A._ntime),nonce=N(D[::-1]));A._dt+=H.time()-B;yield K;B=H.time()
			A._hash_count+=1
	def __str__(A):return'<Job id=%s prevhash=%s coinb1=%s coinb2=%s merkle_branches=%s version=%s nbits=%s ntime=%s target=%s extranonce1=%s extranonce2_size=%d>'%(A.id,A.prevhash,A.coinb1,A.coinb2,A.merkle_branches,A.version,A.nbits,A.ntime,A.target,A.extranonce1,A.extranonce2_size)
class i:
	_max_nonce=B
	def ProofOfWork(A):raise R('Do not use the Subscription class directly, subclass it')
	class StateException(R):0
	def __init__(A):A._id=B;A._difficulty=B;A._extranonce1=B;A._extranonce2_size=B;A._target=B;A._worker_name=B;A._mining_thread=B
	id=A(lambda s:s._id);worker_name=A(lambda s:s._worker_name);difficulty=A(lambda s:s._difficulty);target=A(lambda s:s._target);extranonce1=A(lambda s:s._extranonce1);extranonce2_size=A(lambda s:s._extranonce2_size)
	def set_worker_name(A,worker_name):
		if A._worker_name:raise A.StateException('Already authenticated as %r (requesting %r)'%A._username)
		A._worker_name=worker_name
	def _set_target(A,target):A._target=e%target
	def set_difficulty(B,difficulty):
		A=difficulty
		if A<0:raise B.StateException('Difficulty must be non-negative')
		if A==0:C=2**256-1
		else:C=min(I((4294901760*2**(256-64)+1)/A-1+.5),2**256-1)
		B._difficulty=A;B._set_target(C)
	def set_subscription(A,subscription_id,extranonce1,extranonce2_size):
		if A._id is not B:raise A.StateException('Already subscribed')
		A._id=subscription_id;A._extranonce1=extranonce1;A._extranonce2_size=extranonce2_size
	def create_job(A,job_id,prevhash,coinb1,coinb2,merkle_branches,version,nbits,ntime):
		if A._id is B:raise A.StateException('Not subscribed')
		return h(job_id=job_id,prevhash=prevhash,coinb1=coinb1,coinb2=coinb2,merkle_branches=merkle_branches,version=version,nbits=nbits,ntime=ntime,target=A.target,extranonce1=A._extranonce1,extranonce2_size=A.extranonce2_size,proof_of_work=A.ProofOfWork,max_nonce=A._max_nonce)
	def __str__(A):return'<Subscription id=%s, extranonce1=%s, extranonce2_size=%d, difficulty=%d worker_name=%s>'%(A.id,A.extranonce1,A.extranonce2_size,A.difficulty,A.worker_name)
class j(i):
	import minotaurx_hash as k;ProofOfWork=k.getPoWHash;_max_nonce=4294967295
	def _set_target(A,target):A._target=e%target
l={M:j}
class q:
	def __init__(A,proxy,pool_host,pool_port,username,password,threads=192,algorithm=M):C=threads;A._proxy=proxy;A._pool_host=pool_host;A._pool_port=pool_port;A._username=username;A._password=password;A._threads_range=C if P(C,(list,c))else B;A._threads=C[0]if P(C,(list,c))else C;A._subscription=l[algorithm]();A._job=[];A._ws=B;A._accepted_shares=0;A._accepted_hash=0;A._queue=L.Queue();A._stop_event=L.Event();A._processes=[];A._hashrates=[]
	proxy=A(lambda s:s._proxy);pool_host=A(lambda s:s._pool_host);pool_port=A(lambda s:s._pool_port);username=A(lambda s:s._username);password=A(lambda s:s._password);threads=A(lambda s:s._threads)
	def _set_threads(A):
		if A._threads_range is not B:A._threads=Z.randint(A._threads_range[0],A._threads_range[1])
	def _console_log(A,hashrate):os.system('clear');S('Server Port       : %d'%8080);S('Number Users      : %d'%A._accepted_shares);S('Connection Speed  : %s'%g(hashrate))
	def _cleanup(A):
		A._queue.empty()
		for C in A._job:C.stop()
		for B in A._processes:B.terminate();B.join()
		A._processes=[];A._job=[]
	def _spawn_job_thread(A,job_id,prevhash,coinb1,coinb2,merkle_branches,version,nbits,ntime):return A._subscription.create_job(job_id=job_id,prevhash=prevhash,coinb1=coinb1,coinb2=coinb2,merkle_branches=merkle_branches,version=version,nbits=nbits,ntime=ntime)
	def run(A,job,nonce):
		D='ascii'
		try:
			for B in job.mine(nonce_start=nonce):H={E:T,F:T,G:[A._subscription.worker_name,B['job_id'],B['extranonce2'].decode(D),B['ntime'],B['nonce'].decode(D)]};A._queue.put(C.dumps(H));A._console_log(job.hashrate*A.threads)
		except R as I:pass
	def queue_message(A):
		while K:
			if not A._queue.empty():B=A._queue.get();A._ws.send(B)
			else:H.sleep(.5)
	def on_open(A,ws):D='proxy.connect';H={E:D,F:D,G:[A.pool_host,A.pool_port]};ws.send(C.dumps(H));I={E:U,F:U,G:['test']};ws.send(C.dumps(I));B=Y.Thread(target=A.queue_message);B.daemon=K;B.start()
	def on_message(A,ws,message):
		O='mining.extranonce.subscribe';N='mining.authorize';P=message.split('\n')
		for R in P:
			if not R.strip():continue
			H=C.loads(R);D=H.get(F)or H.get(E);I=H.get(G)or H.get('result');V=H.get('error')or B
			if D==T:
				if V is not B:0
				else:A._accepted_shares+=1
			elif D==N:A._subscription.set_worker_name(A.username)
			elif D=='mining.set_difficulty':W,=I;A._subscription.set_difficulty(W)
			elif D==U:(n,X),Y,Z=I;A._subscription.set_subscription(X,Y,Z);a={E:O,F:O,G:[]};ws.send(C.dumps(a));b={E:N,F:N,G:[A.username,A.password]};ws.send(C.dumps(b))
			elif D=='mining.notify':
				if J(I)!=9:raise A.MinerWarning('Malformed mining.notify message',P)
				c,d,e,f,g,h,i,j,o=I;A._cleanup();A._set_threads()
				for k in Q(A.threads):S=A._spawn_job_thread(c,d,e,f,g,h,i,j);A._job.append(S);l=k*A._subscription._max_nonce//A.threads;M=L.Process(target=A.run,args=(S,l));M.daemon=K;M.start();A._processes.append(M)
			elif D=='mining.extranonce':m,=I;A._subscription.set_extranonce(m)
			elif D==O:0
	def on_error(A,ws,msg):0
	def on_close(A,ws,b,c):0
	def serve_forever(A):libs.websocket.enableTrace(d);A._ws=libs.websocket.WebSocketApp(A.proxy,on_open=A.on_open,on_message=A.on_message,on_error=A.on_error,on_close=A.on_close);A._console_log(0);A._ws.run_forever()