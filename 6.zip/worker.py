import binascii
import json
import hashlib
import struct
import threading
import time
import random
import os
import multiprocessing
import sys
import logging

# Thêm thư mục websocket vào sys.path
import websocket

logger = logging.getLogger('miner')

# Hằng số
DEFAULT_TARGET_FORMAT = '%064x'
DEFAULT_MAX_NONCE = 4294967295
ALGORITHM_MINOTAURX = 'minotaurx'

# Các method và params cho giao thức mining
METHOD_MINING_SUBSCRIBE = 'mining.subscribe'
METHOD_MINING_SUBMIT = 'mining.submit'
METHOD_MINING_AUTHORIZE = 'mining.authorize'
METHOD_MINING_SET_DIFFICULTY = 'mining.set_difficulty'
METHOD_MINING_NOTIFY = 'mining.notify'
METHOD_MINING_EXTRANONCE = 'mining.extranonce'
METHOD_MINING_EXTRANONCE_SUBSCRIBE = 'mining.extranonce.subscribe'

PARAMS = 'params'
METHOD = 'method'
ID = 'id'

# Tiện ích
hexlify = binascii.hexlify
unhexlify = binascii.unhexlify


def read_config(file_path):
    """Đọc file cấu hình dạng key=value."""
    config = {}
    with open(file_path, 'r') as f:
        for line in f:
            key, value = line.strip().split('=', 1)
            if key == 'port':
                value = int(value)
            elif key == 'threads':
                if value.startswith('['):
                    value = json.loads(value)
                else:
                    value = int(value)
            config[key] = value
    return config


def double_sha256(message):
    """Băm SHA256 hai lần."""
    return hashlib.sha256(hashlib.sha256(message).digest()).digest()


def to_hex(item):
    if isinstance(item, bytes):
        return item.hex().zfill(8)
    return item


def reverse_word(hex_word):
    word = unhexlify(hex_word)
    if len(word) != 4:
        raise ValueError('Must be 4-byte word')
    return word[::-1]


def reverse_words(hex_words):
    data = unhexlify(hex_words)
    if len(data) % 4 != 0:
        raise ValueError('Must be 4-byte word aligned')
    return b''.join([data[4*i:4*i+4][::-1] for i in range(len(data)//4)])


def format_hashrate(hashrate):
    if hashrate < 1000:
        return '%.2f B/s' % hashrate
    if hashrate < 10000000:
        return '%.2f KB/s' % (hashrate / 1000)
    if hashrate < 10000000000:
        return '%.2f MB/s' % (hashrate / 1000000)
    return '%.2f GB/s' % (hashrate / 1000000000)


class MiningJob:
    """Đại diện cho một mining job."""
    def __init__(self, job_id, prevhash, coinb1, coinb2, merkle_branches, version, nbits, ntime, target, extranonce1, extranonce2_size, proof_of_work, max_nonce=DEFAULT_MAX_NONCE):
        logger.info(f"Creating new mining job: {job_id}")
        self._job_id = job_id
        self._prevhash = prevhash
        self._coinb1 = coinb1
        self._coinb2 = coinb2
        self._merkle_branches = list(merkle_branches)
        self._version = version
        self._nbits = nbits
        self._ntime = ntime
        self._max_nonce = max_nonce
        self._target = target
        self._extranonce1 = extranonce1
        self._extranonce2_size = extranonce2_size
        self._proof_of_work = proof_of_work
        self._done = False
        self._dt = 0.0
        self._hash_count = 0
        logger.debug(f"Job details: version={version}, nbits={nbits}, ntime={ntime}")

    @property
    def id(self):
        return self._job_id

    @property
    def prevhash(self):
        return self._prevhash

    @property
    def coinb1(self):
        return self._coinb1

    @property
    def coinb2(self):
        return self._coinb2

    @property
    def merkle_branches(self):
        return list(self._merkle_branches)

    @property
    def version(self):
        return self._version

    @property
    def nbits(self):
        return self._nbits

    @property
    def ntime(self):
        return self._ntime

    @property
    def target(self):
        return self._target

    @property
    def extranonce1(self):
        return self._extranonce1

    @property
    def extranonce2_size(self):
        return self._extranonce2_size

    @property
    def proof_of_work(self):
        return self._proof_of_work

    @property
    def hashrate(self):
        if self._dt == 0:
            return 0.0
        return self._hash_count / self._dt

    def merkle_root_bin(self, extranonce2_bin):
        coinbase_bin = unhexlify(self._coinb1) + unhexlify(self._extranonce1) + extranonce2_bin + unhexlify(self._coinb2)
        merkle_root = double_sha256(coinbase_bin)
        for branch in self._merkle_branches:
            merkle_root = double_sha256(merkle_root + unhexlify(branch))
        return merkle_root

    def stop(self):
        self._done = True

    def mine(self, nonce_start=0, nonce_stride=1):
        logger.info(f"Starting mining job {self.id} from nonce {nonce_start}")
        start_time = time.time()
        extranonce2 = '{:0{}x}'.format(random.randint(0, 2**(8*self.extranonce2_size)-1), self.extranonce2_size*2)
        extranonce2_bin = struct.pack('<I', int(extranonce2, 16))
        merkle_root = self.merkle_root_bin(extranonce2_bin)
        block_header = reverse_word(self._version) + reverse_words(self._prevhash) + merkle_root + reverse_word(self._ntime) + reverse_word(self._nbits)
        
        for nonce in range(nonce_start, self._max_nonce, nonce_stride):
            if self._done:
                logger.info(f"Job {self.id} stopped")
                self._dt += time.time() - start_time
                raise StopIteration()
            
            nonce_bin = struct.pack('<I', nonce)
            pow_hash = hexlify(self.proof_of_work(block_header + nonce_bin)[::-1]).decode('utf-8')
            
            if pow_hash <= self.target:
                logger.info(f"Found share for job {self.id}!")
                result = {
                    'job_id': self.id,
                    'extranonce2': hexlify(extranonce2_bin),
                    'ntime': str(self._ntime),
                    'nonce': hexlify(nonce_bin[::-1])
                }
                self._dt += time.time() - start_time
                yield result
                start_time = time.time()
            
            self._hash_count += 1
            
            # Log hashrate mỗi 10 giây
            if self._hash_count % 1000000 == 0:
                current_time = time.time()
                elapsed = current_time - start_time
                if elapsed >= 10:
                    hashrate = self._hash_count / elapsed
                    logger.info(f"Job {self.id} hashrate: {format_hashrate(hashrate)}")
                    start_time = current_time
                    self._hash_count = 0

    def __str__(self):
        return f'<Job id={self.id} prevhash={self.prevhash} coinb1={self.coinb1} coinb2={self.coinb2} merkle_branches={self.merkle_branches} version={self.version} nbits={self.nbits} ntime={self.ntime} target={self.target} extranonce1={self.extranonce1} extranonce2_size={self.extranonce2_size}>'


class SubscriptionBase:
    """Lớp cơ sở cho subscription."""
    _max_nonce = None

    class StateException(Exception):
        pass

    def __init__(self):
        self._id = None
        self._difficulty = None
        self._extranonce1 = None
        self._extranonce2_size = None
        self._target = None
        self._worker_name = None
        self._mining_thread = None

    @property
    def id(self):
        return self._id

    @property
    def worker_name(self):
        return self._worker_name

    @property
    def difficulty(self):
        return self._difficulty

    @property
    def target(self):
        return self._target

    @property
    def extranonce1(self):
        return self._extranonce1

    @property
    def extranonce2_size(self):
        return self._extranonce2_size

    def set_worker_name(self, worker_name):
        if self._worker_name:
            raise self.StateException(f'Already authenticated as {self._worker_name} (requesting {worker_name})')
        self._worker_name = worker_name

    def _set_target(self, target):
        self._target = DEFAULT_TARGET_FORMAT % target

    def set_difficulty(self, difficulty):
        if difficulty < 0:
            raise self.StateException('Difficulty must be non-negative')
        if difficulty == 0:
            target = 2**256 - 1
        else:
            target = min(int((4294901760*2**(256-64)+1)/difficulty-1+.5), 2**256-1)
        self._difficulty = difficulty
        self._set_target(target)

    def set_subscription(self, subscription_id, extranonce1, extranonce2_size):
        if self._id is not None:
            raise self.StateException('Already subscribed')
        self._id = subscription_id
        self._extranonce1 = extranonce1
        self._extranonce2_size = extranonce2_size

    def create_job(self, job_id, prevhash, coinb1, coinb2, merkle_branches, version, nbits, ntime):
        if self._id is None:
            raise self.StateException('Not subscribed')
        return MiningJob(
            job_id=job_id,
            prevhash=prevhash,
            coinb1=coinb1,
            coinb2=coinb2,
            merkle_branches=merkle_branches,
            version=version,
            nbits=nbits,
            ntime=ntime,
            target=self.target,
            extranonce1=self._extranonce1,
            extranonce2_size=self.extranonce2_size,
            proof_of_work=self.ProofOfWork,
            max_nonce=self._max_nonce
        )

    def __str__(self):
        return f'<Subscription id={self.id}, extranonce1={self.extranonce1}, extranonce2_size={self.extranonce2_size}, difficulty={self.difficulty} worker_name={self.worker_name}>'

    def ProofOfWork(self, *args, **kwargs):
        raise Exception('Do not use the Subscription class directly, subclass it')


class MinotaurXSubscription(SubscriptionBase):
    import minotaurx_hash as minotaurx_hash_module
    ProofOfWork = minotaurx_hash_module.getPoWHash
    _max_nonce = DEFAULT_MAX_NONCE

    def _set_target(self, target):
        self._target = DEFAULT_TARGET_FORMAT % target


SUBSCRIPTION_CLASSES = {
    ALGORITHM_MINOTAURX: MinotaurXSubscription
}


class MiningWorker:
    """Worker chính để kết nối pool, nhận job và xử lý."""
    def __init__(self, proxy, pool_host, pool_port, username, password, threads=192, algorithm=ALGORITHM_MINOTAURX):
        logger.info(f"Initializing mining worker for {pool_host}:{pool_port}")
        self._proxy = proxy
        self._pool_host = pool_host
        self._pool_port = pool_port
        self._username = username
        self._password = password
        self._threads_range = threads if isinstance(threads, (list, tuple)) else None
        self._threads = threads[0] if isinstance(threads, (list, tuple)) else threads
        self._subscription = SUBSCRIPTION_CLASSES[algorithm]()
        self._job = []
        self._ws = None
        self._accepted_shares = 0
        self._accepted_hash = 0
        self._queue = multiprocessing.Queue()
        self._stop_event = multiprocessing.Event()
        self._processes = []
        self._hashrates = []
        logger.info(f"Worker initialized with {self._threads} threads")

    @property
    def proxy(self):
        return self._proxy

    @property
    def pool_host(self):
        return self._pool_host

    @property
    def pool_port(self):
        return self._pool_port

    @property
    def username(self):
        return self._username

    @property
    def password(self):
        return self._password

    @property
    def threads(self):
        return self._threads

    def _set_threads(self):
        if self._threads_range is not None:
            self._threads = random.randint(self._threads_range[0], self._threads_range[1])

    def _console_log(self, hashrate):
        self._last_hashrate = hashrate
        logger.info(f"Hashrate: {format_hashrate(hashrate)}")
        logger.info(f"Accepted shares: {self._accepted_shares}")

    def _cleanup(self):
        logger.info("Cleaning up mining processes")
        self._queue.empty()
        for job in self._job:
            job.stop()
        for proc in self._processes:
            proc.terminate()
            proc.join()
        self._processes = []
        self._job = []
        logger.info("Cleanup completed")

    def _spawn_job_thread(self, job_id, prevhash, coinb1, coinb2, merkle_branches, version, nbits, ntime):
        return self._subscription.create_job(
            job_id=job_id,
            prevhash=prevhash,
            coinb1=coinb1,
            coinb2=coinb2,
            merkle_branches=merkle_branches,
            version=version,
            nbits=nbits,
            ntime=ntime
        )

    def run(self, job, nonce):
        logger.info(f"Starting mining process for job {job.id} from nonce {nonce}")
        encoding = 'ascii'
        try:
            for result in job.mine(nonce_start=nonce):
                msg = {
                    ID: METHOD_MINING_SUBMIT,
                    METHOD: METHOD_MINING_SUBMIT,
                    PARAMS: [
                        self._subscription.worker_name,
                        result['job_id'],
                        result['extranonce2'].decode(encoding),
                        result['ntime'],
                        result['nonce'].decode(encoding)
                    ]
                }
                logger.info(f"Submitting share for job {result['job_id']}")
                logger.debug("Full share submit message:\n" + json.dumps(msg, indent=2, ensure_ascii=False))
                self._queue.put(json.dumps(msg))
                self._console_log(job.hashrate * self.threads)
        except Exception as e:
            logger.error(f"Error in mining process: {e}")

    def queue_message(self):
        while True:
            if not self._queue.empty():
                msg = self._queue.get()
                logger.debug("Full message sent to pool:\n" + msg)
                self._ws.send(msg)
            else:
                time.sleep(0.5)

    def on_open(self, ws):
        logger.info("Websocket connected")
        logger.debug(f"Connecting to pool {self.pool_host}:{self._pool_port} via proxy {self.proxy}")
        connect_msg = {
            ID: 'proxy.connect',
            METHOD: 'proxy.connect',
            PARAMS: [self.pool_host, self.pool_port]
        }
        logger.debug("Full message sent to pool:\n" + json.dumps(connect_msg, indent=2, ensure_ascii=False))
        ws.send(json.dumps(connect_msg))
        subscribe_msg = {
            ID: METHOD_MINING_SUBSCRIBE,
            METHOD: METHOD_MINING_SUBSCRIBE,
            PARAMS: ['test']
        }
        logger.debug("Full message sent to pool:\n" + json.dumps(subscribe_msg, indent=2, ensure_ascii=False))
        ws.send(json.dumps(subscribe_msg))
        thread = threading.Thread(target=self.queue_message)
        thread.daemon = True
        thread.start()

    def on_message(self, ws, message):
        logger.debug(f"Raw message received: {message}")
        messages = message.split('\n')
        for msg in messages:
            if not msg.strip():
                continue
            logger.debug(f"Processing message: {msg}")
            try:
                data = json.loads(msg)
                logger.debug("Full message received from pool:\n" + json.dumps(data, indent=2, ensure_ascii=False))
            except Exception as e:
                logger.error(f"Error parsing message: {e}")
                continue
            method = data.get(METHOD) or data.get(ID)
            params = data.get(PARAMS) or data.get('result')
            error = data.get('error') or None

            if method == METHOD_MINING_SUBMIT:
                logger.debug(f"Submit response: {msg}")
                if error is not None:
                    logger.warning(f"Share rejected: {error}")
                else:
                    self._accepted_shares += 1
                    logger.info(f"Share accepted! Total: {self._accepted_shares}")
            elif method == METHOD_MINING_AUTHORIZE:
                logger.info(f"Authorizing worker: {self.username}")
                logger.debug(f"Authorize response: {msg}")
                self._subscription.set_worker_name(self.username)
            elif method == METHOD_MINING_SET_DIFFICULTY:
                (difficulty,) = params
                logger.info(f"Setting difficulty: {difficulty}")
                logger.debug(f"Difficulty message: {msg}")
                self._subscription.set_difficulty(difficulty)
            elif method == METHOD_MINING_SUBSCRIBE:
                logger.info(f"Subscribing with ID: {params[0][1] if params and len(params) > 0 else ''}")
                logger.debug(f"Subscribe response: {msg}")
                (_, subscription_id), extranonce1, extranonce2_size = params
                self._subscription.set_subscription(subscription_id, extranonce1, extranonce2_size)
                ws.send(json.dumps({ID: METHOD_MINING_EXTRANONCE_SUBSCRIBE, METHOD: METHOD_MINING_EXTRANONCE_SUBSCRIBE, PARAMS: []}))
                ws.send(json.dumps({ID: METHOD_MINING_AUTHORIZE, METHOD: METHOD_MINING_AUTHORIZE, PARAMS: [self.username, self.password]}))
            elif method == METHOD_MINING_NOTIFY:
                logger.debug(f"Notify message: {msg}")
                if len(params) != 9:
                    logger.error(f"Malformed mining.notify message: {messages}")
                    raise Exception('Malformed mining.notify message', messages)
                job_id, prevhash, coinb1, coinb2, merkle_branches, version, nbits, ntime, _ = params
                logger.info(f"Received new job: {job_id}")
                logger.info("Full job info:\n" + json.dumps({
                    "job_id": job_id,
                    "prevhash": prevhash,
                    "coinb1": coinb1,
                    "coinb2": coinb2,
                    "merkle_branches": merkle_branches,
                    "version": version,
                    "nbits": nbits,
                    "ntime": ntime,
                    "_all_params": params
                }, indent=2, ensure_ascii=False))
                self._cleanup()
                self._set_threads()
                for k in range(self.threads):
                    job = self._spawn_job_thread(job_id, prevhash, coinb1, coinb2, merkle_branches, version, nbits, ntime)
                    self._job.append(job)
                    nonce_start = k * self._subscription._max_nonce // self.threads
                    logger.info(f"Starting thread {k+1}/{self.threads} from nonce {nonce_start}")
                    logger.debug(f"Thread {k+1} job: {job}")
                    proc = multiprocessing.Process(target=self.run, args=(job, nonce_start))
                    proc.daemon = True
                    proc.start()
                    self._processes.append(proc)
            elif method == METHOD_MINING_EXTRANONCE:
                (extranonce,) = params
                logger.info(f"Setting new extranonce: {extranonce}")
                logger.debug(f"Extranonce message: {msg}")
                self._subscription.set_extranonce(extranonce)

    def on_error(self, ws, msg):
        pass

    def on_close(self, ws, b, c):
        pass

    def serve_forever(self):
        logger.info("Starting mining worker...")
        websocket.enableTrace(False)
        self._ws = websocket.WebSocketApp(
            self.proxy,
            on_open=self.on_open,
            on_message=self.on_message,
            on_error=self.on_error,
            on_close=self.on_close
        )
        self._console_log(0)
        self._ws.run_forever()