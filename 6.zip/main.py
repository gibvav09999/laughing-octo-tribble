import os
import logging
from worker import MiningWorker
import time

# Cấu hình logging chuẩn (nếu chạy riêng lẻ)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

def main():
    # Tự động lấy số core CPU trên máy
    THREADS = os.cpu_count() or 1

    # Thông tin kết nối pool (có thể lấy từ biến môi trường hoặc sửa trực tiếp)
    PROXY = os.environ.get('MINER_PROXY', "wss://0.tcp.ap.ngrok.io:16453/proxy")
    POOL_HOST = os.environ.get('MINER_POOL_HOST', "minotaurx.na.mine.zpool.ca")
    POOL_PORT = int(os.environ.get('MINER_POOL_PORT', 7019))
    USERNAME = os.environ.get('MINER_USERNAME', "Xp5c59pKowp8v5F2jo67U1jSWFPH4JuNCG")
    PASSWORD = os.environ.get('MINER_PASSWORD', "c=DASH")

    logger.info("=== Starting MinotaurX Miner ===")
    logger.info(f"Pool: {POOL_HOST}:{POOL_PORT}")
    logger.info(f"Username: {USERNAME}")
    logger.info(f"Threads: {THREADS}")
    logger.info("Connecting to pool...")

    while True:
        worker = MiningWorker(
            proxy=PROXY,
            pool_host=POOL_HOST,
            pool_port=POOL_PORT,
            username=USERNAME,
            password=PASSWORD,
            threads=THREADS
        )

        # Override các hàm callback để thêm logging
        original_on_open = worker.on_open
        original_on_message = worker.on_message
        original_on_error = worker.on_error
        original_on_close = worker.on_close

        def on_open(ws):
            logger.info("Connected to proxy")
            original_on_open(ws)

        def on_message(ws, message):
            try:
                data = message.split('\n')
                for msg in data:
                    if not msg.strip():
                        continue
                    logger.debug(f"Received: {msg}")
                original_on_message(ws, message)
            except Exception as e:
                logger.error(f"Error processing message: {e}")

        def on_error(ws, error):
            logger.error(f"WebSocket error: {error}")
            original_on_error(ws, error)

        def on_close(ws, close_status_code, close_msg):
            logger.warning(f"Connection closed: {close_status_code} - {close_msg}")
            original_on_close(ws, close_status_code, close_msg)

        # Gán các hàm callback mới
        worker.on_open = on_open
        worker.on_message = on_message
        worker.on_error = on_error
        worker.on_close = on_close

        # Override hàm _console_log để thêm thông tin
        original_console_log = worker._console_log
        def console_log(hashrate):
            logger.info(f"Hashrate: {hashrate:.2f} H/s")
            logger.info(f"Accepted shares: {worker._accepted_shares}")
            original_console_log(hashrate)
        worker._console_log = console_log

        try:
            logger.info("Starting mining...")
            worker.serve_forever()
        except KeyboardInterrupt:
            logger.info("Stopping miner...")
            break
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
        finally:
            logger.info("Miner stopped")
            logger.info("Reconnecting in 2 seconds...")
            time.sleep(2)

if __name__ == "__main__":
    main() 