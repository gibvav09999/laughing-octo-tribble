from worker import q, n

if __name__ == '__main__':
    config = n('data.txt')
    server = q(config['proxy'], config['host'], config['port'], config['username'], config['password'], config['threads'])
    server.serve_forever()